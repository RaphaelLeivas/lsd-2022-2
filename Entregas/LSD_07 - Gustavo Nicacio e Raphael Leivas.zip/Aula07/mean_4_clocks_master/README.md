# mean-4-clocks
Faulty model designed to calculate the mean value over 4 clock periods

1. Implement the testbench;
1. Find the errors;
1. Correct the errors.
